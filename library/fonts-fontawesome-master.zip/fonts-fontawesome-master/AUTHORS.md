## Font Designer
* Dave Gandy

## Developers
* Benjamin P. Jung


